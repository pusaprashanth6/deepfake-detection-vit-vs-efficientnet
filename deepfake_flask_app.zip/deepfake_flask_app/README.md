# Run locally
1. Extract the ZIP.
2. Create a virtual environment.
3. Run `pip install -r requirements.txt`.
4. Run `python app.py`.
5. Open http://127.0.0.1:5000
