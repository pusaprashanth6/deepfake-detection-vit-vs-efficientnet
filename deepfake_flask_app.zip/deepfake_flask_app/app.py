
import tempfile
from pathlib import Path
import cv2, numpy as np, torch, timm
from PIL import Image
from flask import Flask,render_template,request
from torchvision import transforms

app=Flask(__name__); app.config["MAX_CONTENT_LENGTH"]=200*1024*1024
BASE=Path(__file__).parent; device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
ck=torch.load(BASE/"deepfake_model.pt",map_location=device)
model=timm.create_model(ck["model_name"],pretrained=False,num_classes=2,drop_rate=.25)
model.load_state_dict(ck["state_dict"]); model.to(device).eval()
tf=transforms.Compose([transforms.Resize((ck["image_size"],ck["image_size"])),transforms.ToTensor(),
                       transforms.Normalize(ck["mean"],ck["std"])])
fd=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")

def crop(frame):
    g=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY); faces=fd.detectMultiScale(g,1.1,5,minSize=(40,40))
    if len(faces):
        x,y,w,h=max(faces,key=lambda z:z[2]*z[3]); mx=int(.2*w); my=int(.2*h)
        return frame[max(0,y-my):min(frame.shape[0],y+h+my),max(0,x-mx):min(frame.shape[1],x+w+mx)]
    h,w=frame.shape[:2]; s=min(h,w); return frame[(h-s)//2:(h+s)//2,(w-s)//2:(w+s)//2]

@torch.no_grad()
def frame_prob(frame):
    rgb=cv2.cvtColor(crop(frame),cv2.COLOR_BGR2RGB)
    x=tf(Image.fromarray(rgb)).unsqueeze(0).to(device)
    return float(torch.softmax(model(x),1)[0,1])

def video_prob(path):
    cap=cv2.VideoCapture(str(path)); n=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    probs=[]
    for idx in np.linspace(0,max(n-1,0),ck["frames_per_video"]).astype(int):
        cap.set(cv2.CAP_PROP_POS_FRAMES,int(idx)); ok,f=cap.read()
        if ok: probs.append(frame_prob(f))
    cap.release()
    if not probs: raise ValueError("No readable frames found.")
    return float(np.mean(probs)),len(probs)

@app.route("/",methods=["GET","POST"])
def index():
    result=error=None
    if request.method=="POST":
        f=request.files.get("file")
        if not f or not f.filename: error="Select an image or video."
        else:
            suffix=Path(f.filename).suffix.lower(); tmp=None
            try:
                with tempfile.NamedTemporaryFile(delete=False,suffix=suffix) as t: f.save(t.name); tmp=Path(t.name)
                if suffix in {".jpg",".jpeg",".png"}:
                    frame=cv2.imread(str(tmp)); p=frame_prob(frame); details="Image analysed"
                else:
                    p,n=video_prob(tmp); details=f"{n} uniformly sampled frames analysed"
                label="FAKE" if p>=ck["threshold"] else "REAL"
                conf=p if label=="FAKE" else 1-p
                result={"label":label,"confidence":100*conf,"fake":100*p,"details":details}
            except Exception as e: error=str(e)
            finally:
                if tmp and tmp.exists(): tmp.unlink()
    return render_template("index.html",result=result,error=error)

if __name__=="__main__": app.run(debug=True,host="127.0.0.1",port=5000)
